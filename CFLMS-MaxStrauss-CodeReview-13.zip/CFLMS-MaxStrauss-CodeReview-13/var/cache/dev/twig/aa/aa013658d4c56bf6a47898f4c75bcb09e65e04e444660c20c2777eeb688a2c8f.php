<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* inc/navbar.html.twig */
class __TwigTemplate_29d81c6978bef8acb7857e5419799b6c2c3f1c1b173a3c58abe6f1b9e4868633 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "inc/navbar.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo03\" aria-controls=\"navbarTogglerDemo03\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
      <span class=\"navbar-toggler-icon\"></span>
    </button>
    <a class=\"navbar-brand\" href=\"/\">Big Events</a>

    <div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo03\">
      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">

        <li class=\"nav-item active\">
          <a class=\"nav-link\" href=\"/\">Home <span class=\"sr-only\">(current)</span></a>
        </li>

        <li class=\"nav-item active\">
          <a class=\"nav-link\" href=\"/\">more about us</a>
        </li>
      </ul>
   
      <form class=\"form-inline my-2 my-lg-0\">
        <input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"Search\" aria-label=\"Search\">
        <button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search</button>
      </form>

         <ul class=\"navbar-nav ml-auto mt-2 mt-lg-0\">
        <li class=\"nav-item active\">
          <a class=\"nav-link\" href=\"/event/new\">Create new Event</a>
        </li>
        
      </ul>
    </div>
  </nav>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "inc/navbar.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo03\" aria-controls=\"navbarTogglerDemo03\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
      <span class=\"navbar-toggler-icon\"></span>
    </button>
    <a class=\"navbar-brand\" href=\"/\">Big Events</a>

    <div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo03\">
      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">

        <li class=\"nav-item active\">
          <a class=\"nav-link\" href=\"/\">Home <span class=\"sr-only\">(current)</span></a>
        </li>

        <li class=\"nav-item active\">
          <a class=\"nav-link\" href=\"/\">more about us</a>
        </li>
      </ul>
   
      <form class=\"form-inline my-2 my-lg-0\">
        <input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"Search\" aria-label=\"Search\">
        <button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search</button>
      </form>

         <ul class=\"navbar-nav ml-auto mt-2 mt-lg-0\">
        <li class=\"nav-item active\">
          <a class=\"nav-link\" href=\"/event/new\">Create new Event</a>
        </li>
        
      </ul>
    </div>
  </nav>

", "inc/navbar.html.twig", "C:\\xampp\\htdocs\\CFLMS-MaxStrauss-CodeReview-13\\templates\\inc\\navbar.html.twig");
    }
}
