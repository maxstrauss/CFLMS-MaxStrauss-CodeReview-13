<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* events/sport.html.twig */
class __TwigTemplate_9b67449fcabf66b8031c3a80ae0862a4572140726a672a5e7c0821f33e06696a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "events/sport.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "events/sport.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Theatre";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        if ((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 5, $this->source); })())) {
            // line 6
            echo "<div style=\"margin-top: 80px\">

    <div class=\"headerbackground my-4\">
        <header>
            <h1 class=\"text-center\">Sports Events</h1>
            <p class=\"text-center\">Browse through the best sports Events in Vienna</p>
        </header>
    </div>
    <hr>
    <div class=\"row\">

        ";
            // line 17
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 17, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
                // line 18
                echo "
        <div class=\"col-lg-4 col-md-6 mb-4\">
            <div class=\"card h-100\">
                <img class=\"card-img-top\" src=\"";
                // line 21
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "image", [], "any", false, false, false, 21), "html", null, true);
                echo "\" alt=\"Event Picture\">
                <div class=\"card-body\">
                    <h4 class=\"card-title text-center h-25\">";
                // line 23
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "name", [], "any", false, false, false, 23), "html", null, true);
                echo "</h4>
                    <hr>
                    <p class=\"card-text\"><span class=\"cardspan\"><b>Classification: </b></span>";
                // line 25
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "type", [], "any", false, false, false, 25), "html", null, true);
                echo "</p>
                    <p class=\"card-text\"><span class=\"cardspan\"><b>Date: </b></span>";
                // line 26
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "date", [], "any", false, false, false, 26), "F j, Y, g:i a"), "html", null, true);
                echo "
                    </p>
                    <p class=\"card-text\"><span class=\"cardspan\"><b>Location: </b></span>";
                // line 28
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "address", [], "any", false, false, false, 28), "html", null, true);
                echo "</p>
                </div>
                <div class=\"card-footer text-center\">
                    <a href=\"/event/";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 31), "html", null, true);
                echo "\" class=\"btn btn-secondary btn-lg btn-block\">Find Out More!</a>
                </div>
            </div>
            <br>
            <br>
        </div>

        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo "
        ";
        } else {
            // line 41
            echo "        <div style=\"margin-top: 80px\"></div>
        <div class=\"headerbackground my-4\">
            <header>
                <h1 class=\"text-center\">Sports Events</h1>
                <p class=\"text-center\">Browse through the best sports plays in Vienna</p>
            </header>
        </div>
        <hr>
        <h1 class=\"text-center\">No Sports Events to display</h1>
    </div>
    ";
        }
        // line 52
        echo "</div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "events/sport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 52,  139 => 41,  135 => 39,  121 => 31,  115 => 28,  110 => 26,  106 => 25,  101 => 23,  96 => 21,  91 => 18,  87 => 17,  74 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Theatre{% endblock %}

{% block body %}{% if events %}
<div style=\"margin-top: 80px\">

    <div class=\"headerbackground my-4\">
        <header>
            <h1 class=\"text-center\">Sports Events</h1>
            <p class=\"text-center\">Browse through the best sports Events in Vienna</p>
        </header>
    </div>
    <hr>
    <div class=\"row\">

        {% for event in events %}

        <div class=\"col-lg-4 col-md-6 mb-4\">
            <div class=\"card h-100\">
                <img class=\"card-img-top\" src=\"{{ event.image }}\" alt=\"Event Picture\">
                <div class=\"card-body\">
                    <h4 class=\"card-title text-center h-25\">{{ event.name }}</h4>
                    <hr>
                    <p class=\"card-text\"><span class=\"cardspan\"><b>Classification: </b></span>{{ event.type }}</p>
                    <p class=\"card-text\"><span class=\"cardspan\"><b>Date: </b></span>{{event.date|date('F j, Y, g:i a')}}
                    </p>
                    <p class=\"card-text\"><span class=\"cardspan\"><b>Location: </b></span>{{ event.address }}</p>
                </div>
                <div class=\"card-footer text-center\">
                    <a href=\"/event/{{ event.id }}\" class=\"btn btn-secondary btn-lg btn-block\">Find Out More!</a>
                </div>
            </div>
            <br>
            <br>
        </div>

        {% endfor %}

        {% else %}
        <div style=\"margin-top: 80px\"></div>
        <div class=\"headerbackground my-4\">
            <header>
                <h1 class=\"text-center\">Sports Events</h1>
                <p class=\"text-center\">Browse through the best sports plays in Vienna</p>
            </header>
        </div>
        <hr>
        <h1 class=\"text-center\">No Sports Events to display</h1>
    </div>
    {% endif %}
</div>
</div>
{% endblock %}", "events/sport.html.twig", "C:\\xampp\\htdocs\\CFLMS-MaxStrauss-CodeReview-13\\templates\\events\\sport.html.twig");
    }
}
