<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* events/index.html.twig */
class __TwigTemplate_49411dd861b3498c67d06fad04b4ce583b95ec8894b8d72ef0e95b5672c501b4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "events/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "events/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Big Events";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    ";
        if ((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 6, $this->source); })())) {
            // line 7
            echo "    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Name</th>
                ";
            // line 12
            echo "                <th>Description</th>
                <th>Image</th>
                <th>Capacity</th>
                <th>Email</th>
                <th>Phonenumber</th>
                <th>Address</th>
                <th>Url</th>
                <th>Type</th>
                <th class=\"pl-5\">Edit</th>
            </tr>
        </thead>
    
    <tbody>
        ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 25, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
                // line 26
                echo "            <tr>
                <td>";
                // line 27
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "name", [], "any", false, false, false, 27), "html", null, true);
                echo "</td>
                ";
                // line 29
                echo "                <td>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "description", [], "any", false, false, false, 29), "html", null, true);
                echo "</td>
                <td><img src=\"";
                // line 30
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "image", [], "any", false, false, false, 30), "html", null, true);
                echo "\" alt=\"img\" style=\"max-width:300px\"></td>
                <td class=\"pt-5\">";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "capacity", [], "any", false, false, false, 31), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 32
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "email", [], "any", false, false, false, 32), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 33
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "phonenumber", [], "any", false, false, false, 33), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 34
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "address", [], "any", false, false, false, 34), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 35
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "url", [], "any", false, false, false, 35), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 36
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "type", [], "any", false, false, false, 36), "html", null, true);
                echo "</td>
                <td><a href=\"/event/";
                // line 37
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 37), "html", null, true);
                echo "\" class=\"btn btn-dark\">Show</a></td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 40
            echo "    </tbody>
</table>
    ";
        } else {
            // line 43
            echo "    <p>No Events to display</p>
    ";
        }
        // line 45
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "events/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 45,  155 => 43,  150 => 40,  141 => 37,  137 => 36,  133 => 35,  129 => 34,  125 => 33,  121 => 32,  117 => 31,  113 => 30,  108 => 29,  104 => 27,  101 => 26,  97 => 25,  82 => 12,  76 => 7,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Big Events{% endblock %}

{% block body %}
    {% if events %}
    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Name</th>
                {# <th class=\"\">Date</th> #}
                <th>Description</th>
                <th>Image</th>
                <th>Capacity</th>
                <th>Email</th>
                <th>Phonenumber</th>
                <th>Address</th>
                <th>Url</th>
                <th>Type</th>
                <th class=\"pl-5\">Edit</th>
            </tr>
        </thead>
    
    <tbody>
        {% for event in events %}
            <tr>
                <td>{{ event.name }}</td>
                {# <td>{{ date.description }}</td> #}
                <td>{{ event.description }}</td>
                <td><img src=\"{{ event.image }}\" alt=\"img\" style=\"max-width:300px\"></td>
                <td class=\"pt-5\">{{event.capacity}}</td>
                <td class=\"pt-5\">{{event.email}}</td>
                <td class=\"pt-5\">{{event.phonenumber}}</td>
                <td class=\"pt-5\">{{event.address}}</td>
                <td class=\"pt-5\">{{event.url}}</td>
                <td class=\"pt-5\">{{event.type}}</td>
                <td><a href=\"/event/{{ event.id }}\" class=\"btn btn-dark\">Show</a></td>
            </tr>
        {% endfor %}
    </tbody>
</table>
    {% else %}
    <p>No Events to display</p>
    {% endif %}

{% endblock %}
", "events/index.html.twig", "C:\\xampp\\htdocs\\CFLMS-MaxStrauss-CodeReview-13\\templates\\events\\index.html.twig");
    }
}
