<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* events/admin.html.twig */
class __TwigTemplate_af1f6443df8699d0682800902f593450319f5f6e1ad49981724a64f363c04f1f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "events/admin.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "events/admin.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Admin Panel";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        if ((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 6, $this->source); })())) {
            // line 7
            echo "
<div style=\"margin-top: 80px\">
    <h1 class=\"text-center\">Admin Panel</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Description</th>
                <th>Image</th>
                <th>Capacity</th>
                <th>Email</th>
                <th>Phonenumber</th>
                <th>Address</th>
                <!-- <th>Url</th> -->
                <th>Type</th>

                <th class=\"pl-5\">Edit</th>
            </tr>
        </thead>
        <tbody>
            ";
            // line 29
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 29, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
                // line 30
                echo "            <tr>
                <td>";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "name", [], "any", false, false, false, 31), "html", null, true);
                echo "</td>
                <td>";
                // line 32
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "date", [], "any", false, false, false, 32), "F j, Y, g:i a"), "html", null, true);
                echo "</td>
                <td>";
                // line 33
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "description", [], "any", false, false, false, 33), "html", null, true);
                echo "</td>
                <td><img src=\"";
                // line 34
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "image", [], "any", false, false, false, 34), "html", null, true);
                echo "\" alt=\"img\" style=\"max-width:200px\"></td>
                <td class=\"pt-5\">";
                // line 35
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "capacity", [], "any", false, false, false, 35), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 36
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "email", [], "any", false, false, false, 36), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 37
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "phonenumber", [], "any", false, false, false, 37), "html", null, true);
                echo "</td>
                <td class=\"pt-5\">";
                // line 38
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "address", [], "any", false, false, false, 38), "html", null, true);
                echo "</td>
                <!-- <td class=\"pt-5\">";
                // line 39
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "url", [], "any", false, false, false, 39), "html", null, true);
                echo "</td> -->
                <td class=\"pt-5\">";
                // line 40
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "type", [], "any", false, false, false, 40), "html", null, true);
                echo "</td>
                <td><a href=\"/event/";
                // line 41
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 41), "html", null, true);
                echo "\" class=\"btn btn-dark\">Show</a></td>
                <td><a href=\"/event/edit/";
                // line 42
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 42), "html", null, true);
                echo "\" class=\"btn btn-light\">Edit</a> </td>
                <td><a href=\"/delete/";
                // line 43
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 43), "html", null, true);
                echo "\" class=\"btn btn-danger\">Delete</a> </td>
            </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "        </tbody>
    </table>
</div>

";
        } else {
            // line 51
            echo "<h1>No Events to display</h1>
";
        }
        // line 53
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "events/admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 53,  170 => 51,  163 => 46,  154 => 43,  150 => 42,  146 => 41,  142 => 40,  138 => 39,  134 => 38,  130 => 37,  126 => 36,  122 => 35,  118 => 34,  114 => 33,  110 => 32,  106 => 31,  103 => 30,  99 => 29,  75 => 7,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Admin Panel{% endblock %}

{% block body %}
{% if events %}

<div style=\"margin-top: 80px\">
    <h1 class=\"text-center\">Admin Panel</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Description</th>
                <th>Image</th>
                <th>Capacity</th>
                <th>Email</th>
                <th>Phonenumber</th>
                <th>Address</th>
                <!-- <th>Url</th> -->
                <th>Type</th>

                <th class=\"pl-5\">Edit</th>
            </tr>
        </thead>
        <tbody>
            {% for event in events %}
            <tr>
                <td>{{ event.name }}</td>
                <td>{{event.date|date('F j, Y, g:i a')}}</td>
                <td>{{ event.description }}</td>
                <td><img src=\"{{ event.image }}\" alt=\"img\" style=\"max-width:200px\"></td>
                <td class=\"pt-5\">{{event.capacity}}</td>
                <td class=\"pt-5\">{{event.email}}</td>
                <td class=\"pt-5\">{{event.phonenumber}}</td>
                <td class=\"pt-5\">{{event.address}}</td>
                <!-- <td class=\"pt-5\">{{event.url}}</td> -->
                <td class=\"pt-5\">{{event.type}}</td>
                <td><a href=\"/event/{{ event.id }}\" class=\"btn btn-dark\">Show</a></td>
                <td><a href=\"/event/edit/{{event.id}}\" class=\"btn btn-light\">Edit</a> </td>
                <td><a href=\"/delete/{{event.id}}\" class=\"btn btn-danger\">Delete</a> </td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>

{% else %}
<h1>No Events to display</h1>
{% endif %}

{% endblock %}", "events/admin.html.twig", "C:\\xampp\\htdocs\\CFLMS-MaxStrauss-CodeReview-13\\templates\\events\\admin.html.twig");
    }
}
