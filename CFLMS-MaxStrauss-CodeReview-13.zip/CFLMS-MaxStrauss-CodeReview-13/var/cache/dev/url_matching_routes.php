<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'event_list', '_controller' => 'App\\Controller\\EventController::index'], null, null, null, false, false, null]],
        '/event/admin' => [[['_route' => 'admin_list', '_controller' => 'App\\Controller\\EventController::admin'], null, null, null, false, false, null]],
        '/event/new' => [[['_route' => 'new_event', '_controller' => 'App\\Controller\\EventController::new'], null, null, null, false, false, null]],
        '/music' => [[['_route' => 'music_page', '_controller' => 'App\\Controller\\EventController::displayMusic'], null, null, null, false, false, null]],
        '/sport' => [[['_route' => 'sport_page', '_controller' => 'App\\Controller\\EventController::displaySport'], null, null, null, false, false, null]],
        '/movie' => [[['_route' => 'movie_page', '_controller' => 'App\\Controller\\EventController::displayMovie'], null, null, null, false, false, null]],
        '/theatre' => [[['_route' => 'theatre_page', '_controller' => 'App\\Controller\\EventController::displayTheatre'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/event/(?'
                    .'|edit/([^/]++)(*:65)'
                    .'|([^/]++)(*:80)'
                .')'
                .'|/delete/([^/]++)(*:104)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        65 => [[['_route' => 'editevent', '_controller' => 'App\\Controller\\EventController::edit'], ['id'], null, null, false, true, null]],
        80 => [[['_route' => 'event_show', '_controller' => 'App\\Controller\\EventController::show'], ['id'], null, null, false, true, null]],
        104 => [
            [['_route' => 'event_delete', '_controller' => 'App\\Controller\\EventController::deleteAction'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
