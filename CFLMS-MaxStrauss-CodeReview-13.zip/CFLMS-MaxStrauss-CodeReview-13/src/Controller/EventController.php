<?php

namespace App\Controller;

use App\Entity\Event;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;


class EventController extends AbstractController
{
    /**
     * @Route("/", name="event_list")
     * @Method({"GET"})
     */
    public function index()
    {

        $events = $this->getDoctrine()->getRepository(Event::class)->findAll();
        return $this->render('events/index.html.twig', array('events' => $events));
    }

    /**
     * @Route("/event/admin", name="admin_list")
     * @Method({"GET"})
     */
    public function admin()
    {

        $events = $this->getDoctrine()->getRepository(Event::class)->findAll();

        return $this->render('events/admin.html.twig', array('events' => $events));
    }

    /**
     * @Route("/event/new", name="new_event")
     * Method({"GET", "POST"})
     */
    public function new(Request $request)
    {
        $event = new Event();

        $form = $this->createFormBuilder($event)
            ->add('name', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('date', DateTimeType::class, array('attr' => array('style' => 'margin-bottom:15px')))
            ->add('description', TextareaType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('image', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('capacity', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('email', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('phonenumber', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('url', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('type', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label' => 'Create new Event', 'attr' => array('class' => 'btn btn-secondary btn-lg btn-block', 'style' => 'margin-bottom:15px')))

            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $event = $form->getData();
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($event);
            $entityManager->flush();


            return $this->redirectToRoute('event_list');
        }

        return $this->render('events/new.html.twig', array(
            'form' => $form->createView()
        ));
    }


    /**
     * @Route("/event/edit/{id}", name="editevent")
     * Method({"GET", "POST"})
     */
    public function edit(Request $request, $id)
    {
        $event = new Event();
        $event = $this->getDoctrine()->getRepository(Event::class)->find($id);


        $form = $this->createFormBuilder($event)
            ->add('name', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('date', DateTimeType::class, array('attr' => array('style' => 'margin-bottom:15px')))
            ->add('description', TextareaType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('image', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('capacity', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('email', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('phonenumber', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('url', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('type', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label' => 'Update', 'attr' => array('class' => 'btn btn-secondary btn-lg btn-block', 'style' => 'margin-bottom:15px')))

            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->flush();

            return $this->redirectToRoute('event_list');
        }

        return $this->render('events/edit.html.twig', array(
            'form' => $form->createView()
        ));
    }


    /**
     * @Route("/event/{id}", name="event_show")
     */
    public function show($id)
    {
        $event = $this->getDoctrine()->getRepository(Event::class)->find($id);

        return $this->render('events/show.html.twig', array('event' => $event));
    }


    /**
     * @Route("/delete/{id}", name="event_delete")
     */
    public function deleteAction($id)
    {
        $entityManager = $this->getDoctrine()->getManager();
        $event = $this->getDoctrine()->getRepository(Event::class)->find($id);
        $entityManager->remove($event);
        $entityManager->flush();

        return $this->redirectToRoute('event_list');
    }





    /**
    * @Route("/music", name="music_page")
    */
    public function displayMusic(){
        $events = $this->getDoctrine()->getRepository
        (Event::class)->findBy(array('type' => 'Music'));

        return $this->render('events/music.html.twig', array('events' => $events));
    }
    /**
    * @Route("/sport", name="sport_page")
    */
    public function displaySport(){
        $events = $this->getDoctrine()->getRepository
        (Event::class)->findBy(array('type' => 'Sport'));

        return $this->render('events/sport.html.twig', array('events' => $events));
    }
    /**
    * @Route("/movie", name="movie_page")
    */
    public function displayMovie(){
        $events = $this->getDoctrine()->getRepository
        (Event::class)->findBy(array('type' => 'Movie'));

        return $this->render('events/movie.html.twig', array('events' => $events));
    }
        /**
    * @Route("/theatre", name="theatre_page")
    */
    public function displayTheatre(){
        $events = $this->getDoctrine()->getRepository
        (Event::class)->findBy(array('type' => 'Theatre'));

        return $this->render('events/theatre.html.twig', array('events' => $events));
    }

}
